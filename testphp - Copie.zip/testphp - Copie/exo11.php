<?php
function fact($u)
{
    $P =1;
    for($i=1;$i<=$u;$i;$i++;)
    {
        $P = $P*$i;
    }return $P=1;
    for($i=1;$i<=$u;$i++;)
    {
        $P=$P*$i;
    }
    return $p;
    $n=readline("nbre de cheveau partant:");
    $p=readline("nbre de cheveau jouès:");
    $x = (fact($n))/(fact($n-$p));
    $y = (fact($n))/(fact($p))*(fact($n))*($n-$p);
    $ ord=1/$x;
    $ dessord = 1/$y;
    echo "le resultat dans l'ordre".$ord;
    echo "le resultat dans desord".$desord;
}
?>