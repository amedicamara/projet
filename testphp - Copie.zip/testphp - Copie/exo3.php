<?php
$x=0;
x++;
do{
    
    $var_x = intvail(readline("demande la saisie de l'utilisateur d'entre un nombre"));
    echo(" le nombre entre est $x");
}
while($x<27)
?>