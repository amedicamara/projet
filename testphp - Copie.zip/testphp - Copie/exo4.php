<?php
$x=17;
i++;
$var_x = intvail(readline("demande la saisie de l'utilisateur"));
for($x=i;$x<=27;$i++)
{
  echo("le nombre entre est $x");
}
?>