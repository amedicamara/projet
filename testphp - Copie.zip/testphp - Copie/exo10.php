<?php
$i =1;
$som=0;
$rest +0;
do
{
    $val=intval(readline"prix du produit en position $i ou entre 0 arreter ");
    if($val==0)
    break;
    if($val==1)
    $yv=="euros";
    $som+=$val;
    $i++;

}
while($val!=0);
echo("\n\n______________payement de client\n\n");
$pay=intval(readline("entrez lz montant verser par client:"));
if($pay==1)
$vp="euro";
else
$vp="euros";
$1==$pay-$som
?>