<?php
$x=0;
$m=0
$m = intvail(readline("demande la saisie de l'utilisateur"));
for(i=1;i<=10;i++)
$m = $x * $i 
echo("\n$x*$i=."$m);
?>