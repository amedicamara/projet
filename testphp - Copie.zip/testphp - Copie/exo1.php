<?php
$x=0;
do
{
    if($x>3||$x<1)
    $var_x = intvail(readline("demande la saisie de l'utilisateur"));
    if($x=3 && $x=1)
    echo("le nombre entre est $x.");
    break
}

while( $x>3 || $x<1)

?>
