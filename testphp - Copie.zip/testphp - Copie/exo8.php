<?php
$x="20";
$nbr = intvail(readline("saisie de nombre"));
$nbre=array("numero1"=>12,"numero2"=>14,"numero20"=>6);
if(nbre>=20)
echo("le numero esr".$x);
?>; 