<?php
$x=0;
$s=0;
$m = intvail(readline("calculer la factorielle"));
for($i=0;$i<=8;i++)
if($i=0)
if($x=0)
echo("$i*$x=".$m");
?>