<?php
$x = 0;
if(x=10 && x <=20)
$var_x = intvail(readline("demande la saisie de l'utilisateur"));
if(x>20)
echo("le nombre est plus petit");
elseif (x<=10||x=20) {
    echo("le nomnre est plus grand");
}


?>