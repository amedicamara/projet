<?php
$x=0;
$y=0;
$m=0;
$m = intvail(readline("calcul de la somme"));
for("$m=o;$m<=15;$m++")
$m=$x+$y
echo("$x+$y=".$m);
?>