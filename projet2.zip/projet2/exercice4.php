<?php
function concatenationSpace ();
$argument1="Mendy";
$argument2="Ousmane";
echo $argument1 . "" . $argument2;
?>

