<?php
 function dernierElement()
 {
     $j=0;
     $arg-array();
 }
 do{
     $arg[$j]=(readline("entrez de text :"));
     if($arg[$j]=="")
     {
         $arg[$j]="null";
     }
     if($arg[$j]=="ok")
     {
         echo "le dernier Element du tableau est ".$arg[$j-1];
         break;
     }
     $j++;
 }
 while($arg[$j]="ok");
}
dernierElement()
?>