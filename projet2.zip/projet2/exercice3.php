<?php
function concatenation ();
$argument1="Antoine";
$argument2="Griezmann";
echo $argument1 . "" . $argument2;
?>