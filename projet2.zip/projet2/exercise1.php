<?php
function le meilleur prof();
{
    $meilleur prof;
    return{
        $meilleur prof=0;
    }
}
?>