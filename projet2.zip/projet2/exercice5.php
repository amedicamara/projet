<?php
function plusPetit()
int $x=10;
int $y=20;
int $Z=5;
if($z<=5){
    echo("le nombre est plus petit".$z)
}
else{
    echo("le nombre est plus grand")
}
?>