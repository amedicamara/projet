<?php
function verifiPWD(){
    $arg=array();
    $i=0;
    do{
        $arg[$i]=(readline("saisir un mot de passe :"));
        if($arg[$i])=="ok")
        break;
        if(strlen($arg[$i])>=8)
        {
            echo "true\nsaisir ok pour arreter\n";
        }
        if(strlen($arg[$i])<8)
        {
            echo "false\nsaisir ok arreter\n";
        }
        $i++;

    
    }
    while($arg[$i]!="ok");

}
verifiPWD();
?>